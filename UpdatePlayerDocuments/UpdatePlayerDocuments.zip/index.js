const mongoose = require('mongoose');
const connectToDatabase = require('./db');
const Match = require('./models/Match');
const Player = require('./models/Player');
const { aggregateWinRate } = require('./utils/winRateUtils');
const { aggregateSynergy } = require('./utils/synergyUtils');

exports.handler = async (event) => {
  await connectToDatabase();
  try {
    // 1. 전체 기간의 player 목록 중복 없이 수집
    const uniquePlayers = await Match.distinct('player');

    // 2.1 각 player별로 첫/마지막 참가 날짜 조회
    const players = await Match.aggregate([
      {
        $group: {
          _id: "$player",
          first: { $min: "$date" },
          last: { $max: "$date" }
        }
      }
    ]);

    // 2.2 각 player별로 가장 최신 Match의 round 조회
    const lastRounds = await Match.aggregate([
      {
        $group: {
          _id: "$player",
          lastRound: { $max: "$round" }
        }
      }
    ]);

    // 5. Player 컬렉션에 upsert
    for (const p of players) {
      const lastRound = lastRounds.find(lr => lr._id === p._id)?.lastRound || 0; // Default to 0 if no match found
      await Player.findOneAndUpdate(
        { player: p._id },
        {
          $set: {
            'dates.first': p.first,
            'dates.last': p.last,
            'dates.LastRound': lastRound, // Set the latest round
          },
          $setOnInsert: {
            isClanMember: false,
            'scores.D': 0,
            'scores.T': 0,
            'scores.H': 0,
          },
        },
        { upsert: true, new: true }
      );
    }

    await aggregateWinRate(Match, Player);
    await aggregateSynergy(Match, Player);


    return {
      statusCode: 200,
      body: JSON.stringify({ message: 'All player data updated successfully.' }),
    };

  } catch (error) {
    console.error('Update failed:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ message: 'Error updating player data.', error }),
    };
  }
};
